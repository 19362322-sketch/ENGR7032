//https://os.mbed.com/users/joelvonrotz/code/VL53L0X/docs/tip/classVL53L0X.html
//http://os.mbed.com/users/joelvonrotz/code/VL53L0X/
#include "mbed.h"
#include "VL53L0X.h"
#include <cmath>
#include <cstdint>
#include <cstdio>
//#include <chrono>
#define UART_BUF_LEN 32 //UART String length
#define SYS_CLK_US 50   //System uptime Intervial in microseconds
#define STEER_ANGLE_MAX 9 //Maxinum angle of Turning
#define STEER_MAX 2       //Maxnium Value of Servo-Control 
#define SERVO_FX 200      //Ratio of "Direction" to "Time Intervial of Control Signal"
#define SERVO_CC 1450     //Const for Center-Center 
#define ECHO_FILITER_RATIO 7 //*[9] = 90%new_result + 10%old_result
#define ToF_FILITER_RATIO 9 
#define DNGS_FILITER_RATIO 9
#define DNGS_UPDATE_FILITER_RATIO 9
#define DNG_CP_LIMIT 120 //Target Value of "Forgeting Danger"
#define DNG_STEER_TRIG 40
#define DIST_CP_RATIO 5  //Encoder.Distance to CP Ratio
#define ToF_DIR_MAX 3 //[2] => ToF_dirs[] ={-2,-1,0,1,2}  
#define Echo_DIR_MAX 30
constexpr double STEER_ANGLE_RATIO = (STEER_ANGLE_MAX)/(double)(STEER_MAX);
constexpr uint8_t DIRECT_COUNT = (uint8_t)(360 / STEER_ANGLE_RATIO);
constexpr uint8_t DIR180 = (uint8_t)(180 / STEER_ANGLE_RATIO);
constexpr uint8_t CP_STEER_RATIO = (uint8_t)(100/STEER_ANGLE_MAX);
int8_t ToF_dirs[] ={-3,-2,-1,0,1,2,3};  //Lookup array fordp implement
int8_t Echo_dirs[] ={4,5,6,7,8,9,10};
double DIR2X[DIRECT_COUNT]; //Lookup table for map updating
double DIR2Y[DIRECT_COUNT];
double DIR2Xs[90];



//System Define
static BufferedSerial UART(USBTX, USBRX);
static Ticker TIMR1;
static I2C        i2c(I2C_SDA, I2C_SCL);
static VL53L0X    ToF(&i2c);
static DigitalOut ToF_SHUT(PB_5);
static DigitalIn  BTN(BUTTON1);
static DigitalOut LED(LED1);
static uint32_t Uptime =0;

uint16_t INTsqrt(double X){
    if(X==0) return 0;
    uint16_t n2 =0;
    uint16_t n1 =0;
    for(uint16_t n=1; n<65534; n++)
    {
        n2 =n*n;
        if(n2 ==X){
            return n;
        }else if(n2 >X){
            if((n2-X) < (X-n1))
                return n;
            else
                return n-1;
        }
        n1 =n2;
    }
    return 0;
}int16_t INTround(double X){
    
    int16_t _Pos =1;
    if(X == 0){
        return 0;
    }else if(X <0){
        _Pos =-1;
        X *=-1;
    }

    if((X*10 -((int16_t)X)*10) >=5)
        return ((int16_t)X+1)*_Pos;
    else
        return ((int16_t)X)*_Pos;
}


//Class Define
class ENCODER_data{
    private:
        uint32_t cnt =0;
        uint32_t timr =0;
        InterruptIn input;
        void trig(){
            cnt++;
        }
    public:
        uint16_t Speed =0;
        uint32_t Distance =1;
        ENCODER_data(PinName pin) : input(pin)
        {
            input.rise(callback(this, &ENCODER_data::trig));
            timr =Uptime;
            cnt =0;
        }
        void update(){
            Speed = (cnt*1000) / ((Uptime -timr)/1000);
            Distance =cnt;
            timr =Uptime;
            cnt =0;
        }
};
class ECHO_data{
    private:
        DigitalOut trig;
        InterruptIn echo;
        bool isON =false;
        uint32_t timer =0;
        void Tstart(){
            if(isON)
                timer = Uptime;
        }void Tstop(){
            if(isON){
                Raw =Uptime -timer;
                result =
                    (Raw *ECHO_FILITER_RATIO
                    +result *(10-ECHO_FILITER_RATIO))
                    /10;         
            }
            isON =false;
        }
    public:
        uint16_t result =0;
        uint16_t Raw =0;
        ECHO_data(PinName trigPin, PinName echoPin) : trig(trigPin), echo(echoPin)
        {
            trig =0;
            echo.rise(callback(this, &ECHO_data::Tstart));
            echo.fall(callback(this, &ECHO_data::Tstop));
        }
        void start()
        {
            isON =true;
            trig =1;
            wait_us(10);
            trig =0;
        }
};
class CPWM{
    private:
        uint16_t timer;
        uint16_t timer_limit;
        DigitalOut output;
        DigitalOut* output2;
        bool has2out =false;
        uint16_t alarm;
    public:
        bool REVERSE =false;
        CPWM(uint16_t timerLimit, PinName pin, DigitalOut* out2 = nullptr) : output(pin)
        {
            output =0;
            timer_limit =timerLimit;
            if(out2 != nullptr)
            {
                output2 = out2;
                has2out = true;
            }
        }
        void update(uint16_t step)
        {
            timer += step;
            if(timer >= timer_limit)
            {
                timer =0;
                output =!REVERSE;
                //if(has2out) output2->write(REVERSE);
            }else if(timer >= alarm){
                output =0;
                //if(has2out) output2->write(0);
            }
        }
        void setAlarm(uint16_t t)
        {
            alarm = t;
        }
};
class DangerPoints{
    /*
     * DP Explained:
     * Saving the CrashPoints based on each segment of angle.
     * for example: 
     *  {90deg, 50% crashing}
     * will be saved as following format:
     *  {(int)(90/STEER_ANGLE_RATIO), 50}
     * Creaing a Radar-Style Map
     */

    public:
        uint8_t Dangers[DIRECT_COUNT] = {0}; //Foreach deg, 0~100 %
        int8_t Target = 0;
        uint16_t cpR = 0;
        uint16_t cpL = 0;
        int16_t cpM = 0;

        void update(int8_t direct, uint8_t cp)
        {
            if(cp ==0){
                cp =130;
                //return;
            }
            direct = (direct+DIRECT_COUNT)%DIRECT_COUNT;
            if(Dangers[direct] ==0){
                Dangers[direct] =cp;
            }else {
                Dangers[direct] = 
                (cp *DNGS_FILITER_RATIO
                +Dangers[direct] *(10-DNGS_FILITER_RATIO))
                /10;
            }
            if(Dangers[direct] >DNG_CP_LIMIT)
                Dangers[direct] =0;
            
        }
        void move(int8_t direct, uint8_t cp)
        {
            if (cp == 0) return;
            /* 
            * Rotating map by shifting array via mapping
            * Example: Dangers[10]
            *  0  1  2  3  4  5  6  7  8  9   +DIRECT_COUNT(10)
            * 10 11 12 13 14 15 16 17 18 19   +direct(-1,for example)
            *  9 10 11 12 13 14 15 16 17 18   %DIRECT_COUNT(10)
            *  9  0  1  2  3  4  5  6  7  8   =dps_new
            */
            uint8_t dps_rotated[DIRECT_COUNT] = {0};
            if(direct != 0){
                int8_t dirN;
                for (uint8_t dir = 0; dir < DIRECT_COUNT; dir++)
                {
                    //dps_rotated[(dir + DIRECT_COUNT - direct) % DIRECT_COUNT] = Dangers[dir];
                    dirN =dir;
                    dirN -= direct;
                    if(dirN <0)
                        dirN +=DIRECT_COUNT;
                    dps_rotated[dirN] =Dangers[dir];
                }
                    
                Target -= direct;
                if(Target <0)
                    Target += DIRECT_COUNT;
                else if(Target >= DIRECT_COUNT)
                    Target %= DIRECT_COUNT; 
            }else{
                for (uint8_t dir = 0; dir < DIRECT_COUNT; dir++)
                    dps_rotated[dir] =Dangers[dir];
            }

            for (uint8_t N = 0; N < DIRECT_COUNT; N++)
                Dangers[N] =0;
            
            //Moving Map
            uint8_t dps_moved[DIRECT_COUNT] = {0};
            uint8_t dp;
            double cpX, cpY, cpXm;
            uint8_t cp_new;
            uint8_t dir, dir_new;
            for (uint8_t N = 0; N < DIRECT_COUNT; N++) 
            {
                dir =N;
                //if(n > DIR180) dir = DIRECT_COUNT -(n-DIR180);
                
                dp = dps_rotated[dir];
                if (dp == 0) continue;
                
                //Get Danger in XY positiion
                cpX = DIR2X[dir] *dp;      //(X position remains)
                cpY = DIR2Y[dir] *dp - cp; //(Y position moved down)
                
                //New cp
                cp_new = INTsqrt(cpX * cpX + cpY * cpY);
                //(uint8_t)round(sqrt(cpX * cpX + cpY * cpY)); //[sqrt() and round()] WILL CAUSE CRASHING
                if((cp_new ==0) || (cp_new >DNG_CP_LIMIT)) continue; //GOD DAMMIT I FOUND THIS BS RIGHT AT REPORT DATE ITS F**LING 0050 ME ANGY >:(
                    
                //Get Direction with new XY position
                cpXm =abs(cpX / cp_new);
                double angle_new = 90;
                double N1, N2;
                
                //Get Angle with lookup table
                for (uint8_t n=1; n<90; n++)
                {
                    N2 = DIR2Xs[n] - cpXm;

                    if (N2 >0)
                    {
                        N1 = abs(DIR2Xs[n-1]- cpXm);
                        if (N1 < N2)
                            angle_new = n - 1;
                        else
                            angle_new = n;
                        break;
                    }
                }
                
                
                //Adjust dimention
                //angle_new = round(angle_new);
                if ((cpX > 0) && (cpY > 0))
                { }
                else if ((cpX > 0) && (cpY < 0))
                    angle_new = 180 - angle_new;
                else if ((cpX <= 0) && (cpY < 0))
                    angle_new = 180 + angle_new;
                else
                    angle_new = 360 - angle_new;
                if (angle_new == 360) angle_new = 0;
                

                //Save result
                dir_new = (uint8_t)INTround(angle_new/STEER_ANGLE_RATIO);
                /*
                if(dps_moved[dir_new]!=0){
                    uint16_t et = cp_new;
                    et *= DNGS_UPDATE_FILITER_RATIO;
                    uint16_t ee = dps_moved[dir_new];
                    ee *= (10-DNGS_UPDATE_FILITER_RATIO);
                    dps_moved[dir_new] =(et +ee)/10;
                    
                    //dps_moved[dir_new] = cp_new;
                }else{
                    dps_moved[dir_new] = cp_new;
                }
                */

            }
            

            
            //Updating Map
            for (uint8_t dir = 0; dir < DIRECT_COUNT; dir++) 
            {
                //Dangers[dir] = dps_moved[dir];
                if (Dangers[dir] > DNG_CP_LIMIT) Dangers[dir] = 0; //Clear out-of-bounds
            }
            
            
            
            
        }
        int8_t steer()
        {
            uint16_t cpC = 0;
            cpM =0;
            cpR =0;
            cpL =0;
            int8_t cp;
            //Right CrashProb
            for (uint8_t dir=1; dir<(90/STEER_ANGLE_RATIO); dir++)
            {
                if((Dangers[dir] <= 0) || (Dangers[dir] >=100))
                    cp =0;
                else
                    cp = 100 - Dangers[dir];     
                if(cpM < cp) cpM = cp;
                
                cpR += cp;
                cpC++;
            }
            if(cpC !=0) cpR /= cpC;
        
            //Left CrashProb
            cpC = 0;
            for (uint8_t dir = (uint8_t)(270 / STEER_ANGLE_RATIO); dir < DIRECT_COUNT; dir++)
            {
                if((Dangers[dir] == 0) || (Dangers[dir] >=100))
                    cp =0;
                else
                    cp = 100 - Dangers[dir]; 
                if(cpM < cp) cpM = cp;
                cpL += cp;
                cpC++;
            }
            if (cpC != 0) cpL /= cpC;
            
            int8_t turn =0;
            if(cpM >DNG_STEER_TRIG){
                turn = (cpL - cpR)>0?  STEER_MAX : -STEER_MAX;
            }else { //Nav back to target
                if(Target != 0)
                {
                    if (Target < DIR180)
                        turn = (STEER_MAX)/2;
                    else
                        turn = -(STEER_MAX)/2;
                }
            }
            return turn;
        }
};



//Global Variables
static ENCODER_data ENCA(PC_0);
static ENCODER_data ENCB(PC_1);
static ECHO_data ECHOA(PC_7, PA_9);
static ECHO_data ECHOB(PA_7, PB_6);
static CPWM SERVO(20000, PB_4);
static DigitalOut MOTOR2(PB_10);
static CPWM MOTOR(10, PA_8, &MOTOR2);
uint16_t ToF_Result =0;
int8_t STEER_OUT =0;
DangerPoints DPS;



//Functions
void TIMR1_FUNC();
void SERVO_SET(CPWM* cpwm, int8_t STEER);
void MOTOR_SET(CPWM* cpwm, int8_t POWER);

void TEST_SENSORs();
void TEST_UPTIME();
void TEST_SERVO();
void TEST_MOTOR();



//Inits
void INIT_UART(){
    //Init UART
    UART.set_baud(115200);
    UART.set_format(8, BufferedSerial::None, 1);
}void INIT_TIMRs(){
    //Init TIMR1
    TIMR1.attach(&TIMR1_FUNC, chrono::microseconds(SYS_CLK_US));
}void INIT_ToF(){
    //Init ToF
    ToF_SHUT = 1;  //turn VL53L0X on
    ToF.init();
    ToF.setModeContinuous();
    ToF.startContinuous();
}void INIT_DANGER(){
    for (int n = 0; n < DIRECT_COUNT; n++)
    {
        double rad = (n * STEER_ANGLE_RATIO) / 180 * 3.14;
        DIR2X[n] = sin(rad);
        DIR2Y[n] = cos(rad);
    }
    for (int n = 0; n < 90; n++)
        DIR2Xs[n] = sin(n / 180.0 * 3.14);
    
    //Generate Testing DPmap
    //for(uint8_t dir=0; dir<DIRECT_COUNT; dir++) DPS.Dangers[dir] = 100-dir;
}



//Procs
void PROC_ECHOs(){
    //Process ECHO_A
    ECHOA.start();
    ThisThread::sleep_for(2ms);

    //Process ECHO_B
    ECHOB.start();

}void PROC_ToF(){
    //Process ToF
    uint16_t dist =ToF.getRangeMillimeters();
    if(dist > 20)
    {
        ToF_Result =
            (dist *ToF_FILITER_RATIO
            +ToF_Result *(10-ToF_FILITER_RATIO))
            /10;
        
    }
}void PROC_ENCs(){
    //Process SPDs
    ENCA.update();
    ENCB.update();
}void PROC_SENSORs(){
    //while(true)
    {
        PROC_ECHOs();
        PROC_ToF();
        PROC_ENCs();
        //ThisThread::sleep_for(25ms); //40Hz
    }
}void PROC_DPSout(){
    //Output DangerMap
    
    char msg[3][UART_BUF_LEN]= {0};
    sprintf(msg[0], "ToF:%4d;", ToF_Result);
    UART.write(msg[0], 9);
    sprintf(msg[1], "ECHOs:%5d,%5d;", ECHOA.Raw, ECHOB.Raw);
    UART.write(msg[1], 18);
    sprintf(msg[2], "ENC:%4d,%4d|", ENCB.Speed, ENCB.Distance);
    UART.write(msg[2], 14);
    

    for(uint8_t dir=0; dir<=DIRECT_COUNT; dir++)
    {
        char buf[UART_BUF_LEN] = {0};
        if(dir ==DIRECT_COUNT)
            sprintf(buf, "99:%03d|", DPS.Target);
        else
            sprintf(buf, "%02d:%03d;", dir, DPS.Dangers[dir]);
        UART.write(buf, 8);
    }

    char buf2[UART_BUF_LEN] = {0};
    sprintf(buf2, "SteerOut:%2d ;CPs:[%d] {%d}\n", STEER_OUT, DPS.cpL-DPS.cpR, DPS.cpM);
    UART.write(buf2, UART_BUF_LEN);

}void PROC_UARTHold(){ //Holding thread until UART recived
    char buf[UART_BUF_LEN] = {0};
    uint8_t num = UART.read(buf, sizeof(buf));
    /*
    while(num==0) {
        num = UART.read(buf, sizeof(buf));
        ThisThread::sleep_for(100ms);
    }
    */

}void PROC_DPSupdate(){ //Update Sensor result to DPmap
    if(ToF_Result >600){
        for(uint8_t n=0; n<sizeof(ToF_dirs); n++)
            DPS.update(ToF_dirs[n], 0);    
    }else{
        for(uint8_t n=0; n<sizeof(ToF_dirs); n++)
            DPS.update(ToF_dirs[n], ToF_Result/5);
    }
    for(uint8_t n=0; n<sizeof(Echo_dirs); n++)
    {
        if(ECHOA.result <2500)
            DPS.update(Echo_dirs[n], ECHOA.result/25);
        else
            DPS.update(Echo_dirs[n], 0);
        
        if(ECHOB.result <2500)
            DPS.update(-Echo_dirs[n], ECHOB.result/25);
        else
            DPS.update(-Echo_dirs[n], 0);
    }
}



int main()
{
    LED =0;
    INIT_UART();
    INIT_TIMRs();
    INIT_ToF();
    INIT_DANGER();

    //Thread sPROC1;
    //sPROC1.start(PROC_SENSORs);

    MOTOR_SET(&MOTOR, 0);
    SERVO_SET(&SERVO, -1);
    
    if(BTN.read() ==1)
        PROC_UARTHold();
    //while(BTN.read() ==1);

    LED =1;
    ThisThread::sleep_for(1000ms);
    MOTOR_SET(&MOTOR, 6);
    while(1)
    {
        LED =1;
        //Sensor Data Processing
        for(uint8_t n=0; n<10; n++)
        {
            PROC_ToF();
            PROC_ECHOs();
            ThisThread::sleep_for(50ms);
        }
        PROC_ENCs();

        //Move DPmap
        DPS.move(STEER_OUT, ENCB.Distance /DIST_CP_RATIO);
        
        //Update DangerMap
        PROC_DPSupdate();
        
        //Update Steering-Servo
        //SERVO_SET(&SERVO, DPS.steer());
        //SERVO_SET(&SERVO, -1);

        //Output DPmap via UART
        PROC_DPSout();
        
        //Hold Process
        LED =0;
        MOTOR_SET(&MOTOR, 0);
        PROC_UARTHold();
        MOTOR_SET(&MOTOR, 6);
        
        //TEST_UPTIME();
        //TEST_SERVO();
        //TEST_MOTOR();
        //ThisThread::sleep_for(500ms);
    }
}

void TIMR1_FUNC(){
    Uptime+=SYS_CLK_US;

    //Process Motor
    MOTOR.update(1);

    //Process Servo
    SERVO.update(SYS_CLK_US);
    
}void SERVO_SET(CPWM* cpwm, int8_t STEER){ //-2(Left) ~0(Center) ~2(Right)
    STEER_OUT = STEER;
    //uint16_t steer = STEER;
    //steer *= -SERVO_FX;
    //steer += SERVO_CC;
    cpwm->setAlarm(SERVO_CC -STEER*SERVO_FX);
}void MOTOR_SET(CPWM* cpwm, int8_t POWER){ //-10 ~0(Stop) ~10(Full)
    if(POWER <0){
        cpwm->setAlarm(POWER);
        cpwm->REVERSE = true;
    }else {
        cpwm->setAlarm(POWER);
        cpwm->REVERSE = false;
    }
}

void TEST_SENSORs(){
    char msg[3][UART_BUF_LEN]= {0};
    sprintf(msg[0], "ToF:%4d;", ToF_Result);
    UART.write(msg[0], UART_BUF_LEN);
    sprintf(msg[1], "ECHOs:%5d,%5d;", ECHOA.Raw, ECHOB.Raw);
    UART.write(msg[1], UART_BUF_LEN);
    sprintf(msg[2], "ENC:%4d,%4d\n", ENCB.Speed, ENCB.Distance);
    UART.write(msg[2], UART_BUF_LEN);
    //ThisThread::sleep_for(40ms);
}void TEST_UPTIME(){
    char msg[UART_BUF_LEN]= {0};
    sprintf(msg, "%9d\n", Uptime);
    UART.write(msg, UART_BUF_LEN);
}void TEST_SERVO(){
    for(int8_t n=-STEER_MAX; n<=STEER_MAX; n++)
    {
        SERVO_SET(&SERVO, n);
        char msg[UART_BUF_LEN]= {0};
        sprintf(msg, "TURN: %d\n", n);
        UART.write(msg, UART_BUF_LEN);
        ThisThread::sleep_for(1000ms);
    }
}void TEST_MOTOR(){
    for(int8_t n=-10; n<=10; n++)
    {
        char msg[UART_BUF_LEN]= {0};
        MOTOR_SET(&MOTOR, n);
        sprintf(msg, "MOTOR_OUT: %d\n", n);
        UART.write(msg, UART_BUF_LEN);
        ThisThread::sleep_for(1000ms);
    }
}
