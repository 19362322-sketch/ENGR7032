//https://os.mbed.com/users/joelvonrotz/code/VL53L0X/docs/tip/classVL53L0X.html
#include "mbed.h"
#include "VL53L0X.h"
#include <chrono>
#define CHARS_LEN 32 //UART String length
#define UPTIME_CLK_US 50 //Uptime Intervial in microseconds
#define SERVO_FX 30 //Ratio of "Angle" to "Time Intervial of Control Signal"
#define SERVO_CC 1450 //Const for Center-Center 
#define ECHO_FILITER_RATIO 1 //*[9] = 90%new_result + 10%old_result
#define SPDS_FILITER_RATIO 3 
#define ToF_FILITER_RATIO 3 
#define DOTS_LIMIT 100

//Hardware Define
static BufferedSerial UART(USBTX, USBRX);
static Ticker TIMR1;
static I2C        i2c(I2C_SDA, I2C_SCL);
static VL53L0X    ToF(&i2c);
static DigitalOut ToF_SHUT(PA_5);
static DigitalOut  ECHO_AT(PC_7);
static InterruptIn ECHO_AR(PA_9);
static DigitalOut  ECHO_BT(PA_7);
static InterruptIn ECHO_BR(PB_6);
static InterruptIn SPD_A(PC_0);
static InterruptIn SPD_B(PC_1);
static DigitalOut DRV_A(PA_8);
static DigitalOut DRV_B(PB_10);
static DigitalOut TURN(PB_4);


//System Variables
uint32_t Uptime =0;
bool ECHO_Aon =false;
bool ECHO_Bon =false;
uint32_t ECHO_ATimr =false;
uint32_t ECHO_BTimr =false;
uint8_t DRV_Timr =0;
uint16_t Servo_Timr =0;


//Data Class Define
class SPD_data{
    private:
        uint32_t cnt;
        uint32_t timr;
        
    public:
        uint16_t Speed(){
            return (cnt*1000) / ((Uptime -timr)/1000);
        }uint32_t Distance(){
            return cnt;
        }void update(){
            timr =Uptime;
            cnt =0;
        }void trig(){
            cnt++;
        }
};


//Global Variables
uint16_t ECHO_Aresult =0;
uint16_t ECHO_Bresult =0;
SPD_data SPDA; //DO NOT Directly Read data from these
SPD_data SPDB; 
uint16_t ToF_Result =0;
uint16_t SPDA_Speed =0;
uint16_t SPDB_Speed =0;
uint32_t SPDA_Dist =0;
uint32_t SPDB_Dist =0;
bool   DRV =true; //Forward?
int8_t THR =0; //0(Stop) ~10(Full)
int8_t Servo_Theta =0; //-10(Left) ~0(Center) ~10(Right)


//Functions
void TIMR1_FUNC();
void TIMR2_FUNC();
void ECHO_AR_Tstart();
void ECHO_AR_Tstop();
void ECHO_BR_Tstart();
void ECHO_BR_Tstop();
void SPD_A_Func();
void SPD_B_Func();

void TEST_SENSORs();
void TEST_MOTOR();
void TEST_SERVO();


//Inits
void INIT_UART(){
    //Init UART
    UART.set_baud(115200);
    UART.set_format(8, BufferedSerial::None, 1);
}void INIT_TIMRs(){
    //Init TIMR1
    TIMR1.attach(&TIMR1_FUNC, chrono::microseconds(UPTIME_CLK_US));
}void INIT_ToF(){
    //Init ToF
    ToF_SHUT = 1;  //turn VL53L0X on
    ToF.init();
    ToF.setModeContinuous();
    ToF.startContinuous();
}void INIT_ECHOs(){
    //Init ECHOs
    ECHO_AT =0;
    ECHO_AR.rise(&ECHO_AR_Tstart);
    ECHO_AR.fall(&ECHO_AR_Tstop);
    ECHO_BT =0;
    ECHO_BR.rise(&ECHO_BR_Tstart);
    ECHO_BR.fall(&ECHO_BR_Tstop);
}void INIT_SPDs(){
    //Init Speed Encoders
    SPD_A.rise(SPD_A_Func);
    SPD_B.rise(SPD_B_Func);
}


//Procs
void PROC_ECHOs(){
    //Process ECHO_A
    ECHO_Aon =true;
    ECHO_AT =1;
    //ThisThread::sleep_for(chrono::milliseconds(1)); //Soft blocking
    wait_us(10); //Hard blocking process for signal timing
    ECHO_AT =0;
    ThisThread::sleep_for(2ms);

    //Process ECHO_B
    ECHO_Bon =true;
    ECHO_BT =1;
    wait_us(10);
    ECHO_BT =0;

}void PROC_ToF(){
    //Process ToF
    uint16_t dist =ToF.getRangeMillimeters();
    if(dist > 20)
    {
        ToF_Result = 
            (dist *ToF_FILITER_RATIO
            +ToF_Result *(10-ToF_FILITER_RATIO))
            /10;
    } 
    
}void PROC_SPDs(){
    //Process SPDs
    
    SPDA_Speed =
        (SPDA.Speed() *SPDS_FILITER_RATIO
        +SPDA_Speed *(10-SPDS_FILITER_RATIO))
        /10;
    SPDA_Dist =SPDA.Distance();
    SPDA.update();
    
    SPDB_Speed =
        (SPDB.Speed() *SPDS_FILITER_RATIO
        +SPDB_Speed *(10-SPDS_FILITER_RATIO))
        /10;
    SPDB_Dist =SPDB.Distance();
    SPDB.update();

}void PROC_SENSORs(){
    //while(true)
    {
        PROC_ECHOs();
        PROC_ToF();
        PROC_SPDs();
        //ThisThread::sleep_for(25ms); //40Hz
    }
}


int main()
{
    INIT_UART();
    INIT_TIMRs();
    INIT_ToF();
    INIT_ECHOs();
    INIT_SPDs();
    
    //Thread sPROC1;
    Thread sPROC1;
    //sPROC1.start(PROC_SENSORs);
    
    //DRV =true;
    //THR =5;
    
    while (true) {
        PROC_SENSORs(); //Hard-Blocking Sensor thread;
        
        ThisThread::sleep_for(50ms); //20Hz
        TEST_SENSORs();
        //TEST_MOTOR();
        //TEST_SERVO();
        //TEST_MOTOR_SPD();
    }
}


void TIMR1_FUNC(){
    Uptime+=UPTIME_CLK_US;

    //Process Motor
    DRV_Timr++;
    if(DRV_Timr>=10){
        DRV_Timr =0;
    }else if(DRV_Timr >THR){
        DRV_A =0;
        DRV_B =0;
    }else{
        DRV_A =DRV;
        DRV_B =!DRV;
    }

    //Process Servo
    Servo_Timr +=UPTIME_CLK_US;
    if(Servo_Timr>=20000){
        TURN =1;
        Servo_Timr =0;
    }else if(Servo_Timr>=(SERVO_CC +Servo_Theta*SERVO_FX)){
        TURN =0;
    }

}void ECHO_AR_Tstart(){
    if(ECHO_Aon)
        ECHO_ATimr = Uptime;
}void ECHO_AR_Tstop(){
    if(ECHO_Aon)
    {
        ECHO_Aresult = 
           ((Uptime-ECHO_ATimr) *ECHO_FILITER_RATIO
            +ECHO_Aresult *(10-ECHO_FILITER_RATIO))
            /10;
        ECHO_Aon =false;
    }
}void ECHO_BR_Tstart(){
    if(ECHO_Bon)
        ECHO_BTimr = Uptime;
}void ECHO_BR_Tstop(){
    if(ECHO_Bon)
    {
        ECHO_Bresult = 
           ((Uptime-ECHO_BTimr) *ECHO_FILITER_RATIO
            +ECHO_Bresult *(10-ECHO_FILITER_RATIO))
            /10;
        ECHO_Bon =false;
    }
    
}void SPD_A_Func(){
    SPDA.trig();
}void SPD_B_Func(){
    SPDB.trig();
}
void TEST_SENSORs(){
    char msg[3][CHARS_LEN]= {0};
    sprintf(msg[0], "ToF:%4d;", ToF_Result);
    UART.write(msg[0], CHARS_LEN);
    sprintf(msg[1], "ECHOs:%5d,%5d;", ECHO_Aresult, ECHO_Bresult);
    UART.write(msg[1], CHARS_LEN);
    sprintf(msg[2], "SPDs:%4d,%4d\n", SPDB_Dist, SPDB_Speed);
    UART.write(msg[2], CHARS_LEN);
    //ThisThread::sleep_for(40ms);
}void TEST_MOTOR(){
    DRV =false;
    for(uint8_t n=0; n<=10; n++)
    {
        char msg[CHARS_LEN]= {0};
        THR =n;
        sprintf(msg, "DRV: -%d\n", THR);
        UART.write(msg, CHARS_LEN);
        ThisThread::sleep_for(3000ms);
    }
    DRV =true;
    for(uint8_t n=0; n<=10; n++)
    {
        char msg[CHARS_LEN]= {0};
        THR =n;
        sprintf(msg, "DRV: %d\n", THR);
        UART.write(msg, CHARS_LEN);
        ThisThread::sleep_for(3000ms);
    }
}void TEST_SERVO(){
    for(int8_t n=-10; n<=10; n++)
    {
        Servo_Theta = n;
        char msg[CHARS_LEN]= {0};
        sprintf(msg, "TURN: %d\n", n);
        UART.write(msg, CHARS_LEN);
        ThisThread::sleep_for(1000ms);
    }
}void TEST_MOTOR_SPD(){
    DRV =true;
        for(uint8_t n=0; n<=10; n++)
        {
            THR =n;
            {
                char msg[CHARS_LEN]= {0};
                sprintf(msg, "[%d]=> ", THR);
                UART.write(msg, CHARS_LEN);
            }

            ThisThread::sleep_for(5000ms);

            {
                char msg[CHARS_LEN]= {0};
                sprintf(msg, "[%4d, %4d]\n", SPDA_Speed, SPDB_Speed);
                UART.write(msg, CHARS_LEN);
            }
        }
}
